package Weapon;

public interface Attackable {
    void attackMotion();
} 
