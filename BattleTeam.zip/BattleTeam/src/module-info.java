/**
 * 
 */
/**
 * 
 */
module BattleTeam {
	requires java.desktop;
} 